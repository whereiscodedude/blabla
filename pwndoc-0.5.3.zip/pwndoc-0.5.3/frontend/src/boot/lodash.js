// import VueLodash from 'vue-lodash'
import Lodash from 'lodash'

export default ({ Vue }) => {
    Vue.prototype.$_ = Lodash
}  