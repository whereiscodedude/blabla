import Affix from 'vue-affix';

export default ({ Vue }) => {
    Vue.use(Affix);
}