<template src='./audits-list.html'></template>

<script src='./audits-list.js'></script>

<style>
.icon-next-to-button {
    padding: 0 12px;
    font-size: 1.5em!important;
}
</style>