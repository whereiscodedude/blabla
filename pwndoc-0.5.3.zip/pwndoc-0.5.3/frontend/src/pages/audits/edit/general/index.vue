<template src='./general.html'></template>

<script src='./general.js'></script>

<style></style>