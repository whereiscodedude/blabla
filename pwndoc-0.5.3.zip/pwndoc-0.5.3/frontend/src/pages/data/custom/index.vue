<template src='./custom.html'></template>

<script src='./custom.js'></script>

<style lang="scss">
.drag-ghost {
  opacity: 0.5;
  background: $grey-4;
}
</style>