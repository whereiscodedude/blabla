<template src='./settings.html'></template>

<script src='./settings.js'></script>

<style>
#toggle {
    padding-bottom: 20px;
    padding-left: 0px;
}

.toggleButton {
    margin: 0px 20px;
    border: 1px solid #3c4759;
}

.icon-update-btn {
    font-size: 1.3em !important;
}
</style>