<template src='./vulnerabilities.html'></template>

<script src='./vulnerabilities.js'></script>

<style lang="sass">
.card-section-merge 
    height: calc(60vh - 173px)
</style>