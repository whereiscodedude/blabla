module.exports = {
    testEnvironment: 'node',
    verbose: true
}